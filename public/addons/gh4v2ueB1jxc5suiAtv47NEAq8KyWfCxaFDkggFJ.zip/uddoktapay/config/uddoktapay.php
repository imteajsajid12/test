<?php

return [
    'api_key' => env('UDDOKTAPAY_API_KEY', '982d381360a69d419689740d9f2e26ce36fb7a50'),
    'api_url' => env('UDDOKTAPAY_API_URL', 'https://sandbox.uddoktapay.com/api/checkout-v2'),
];